import java.awt.Color;

import javax.swing.JPanel;

public class Blackout extends JPanel
{
    public Blackout()
    {
        setBackground(Color.BLACK);
        setVisible(true);
        setOpaque(true);
    }
}
